# isgameTemplate
